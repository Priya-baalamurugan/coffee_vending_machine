﻿namespace Smart_Coffee_Vending_Machine.Models
{
    public class CoffeeVending
    {
        public string? prepared { get; set; }

        public string? message { get; set; }
    }
}
