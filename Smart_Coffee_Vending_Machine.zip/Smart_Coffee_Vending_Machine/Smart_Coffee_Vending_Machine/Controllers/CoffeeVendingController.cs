﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using Microsoft.AspNetCore.Http;
using Smart_Coffee_Vending_Machine.Models;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.CompilerServices;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace Smart_Coffee_Vending_Machine.Controllers
{
     
    public class CoffeeVendingController : Controller
    {
        private readonly ILogger<CoffeeVendingController> _logger;
        private readonly IConfiguration _configuration;

        public CoffeeVendingController(ILogger<CoffeeVendingController> logger,IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        [HttpGet("brew-coffee")]
        public async Task<IActionResult> GetCoffee()
        {
            DateTime currentDate = DateTime.Now;
            string returnMessage;
            try
            {
                if (currentDate != null && currentDate == new DateTime(2011, 4, 1))
                {

                    Response.StatusCode = StatusCodes.Status418ImATeapot;

                }
                else
                {
                    Response.StatusCode = StatusCodes.Status200OK;
                    OpenWeatherAPIController objcontroller = new OpenWeatherAPIController(_configuration,_logger);
                    var temperature = await objcontroller.GetCurrentTemperature();
                    double weatherCelsius = 0.0;
                    if ((temperature != null) || (temperature != string.Empty))
                    {
                        weatherCelsius = tempconversionfromkelvintoCelsius(temperature);
                    }
                    if (weatherCelsius > 30)
                    {
                        returnMessage = _configuration.GetValue<string>("icedCoffeeMessage");
                    }
                    else
                    {
                        returnMessage = _configuration.GetValue<string>("hotCoffeeMessage");
                    }

                    var result =
                     new CoffeeVending
                     {
                         prepared = currentDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss+hhmm"),
                         message = returnMessage

                     };
                    return new JsonResult(result);
                }

                
            }
            catch (HttpRequestException httpRequestException)
            {
                _logger.LogError("Error in Getting Coffee",httpRequestException.Message);
                
            }
            return new JsonResult(new EmptyResult());
        }

        private double tempconversionfromkelvintoCelsius(string temperature)
        {
           return Convert.ToDouble(temperature) - 273.15;
            
        }
    }
}
