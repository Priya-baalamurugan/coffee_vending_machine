﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Smart_Coffee_Vending_Machine.Models;

namespace Smart_Coffee_Vending_Machine.Controllers
{
    public class OpenWeatherAPIController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<CoffeeVendingController> _logger;
        
        public OpenWeatherAPIController(IConfiguration configuration,ILogger<CoffeeVendingController> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

      
        public async Task<String> GetCurrentTemperature()
        {
           
            using (var client = new HttpClient())
            {
                string temp = "";
                try
                {
                    client.BaseAddress = new Uri(string.Format("https://api.openweathermap.org/data/2.5/weather"));
                    string cityName = _configuration.GetValue<string>("cityName");
                    string api_key = _configuration.GetValue<string>("api_key");


                    var response = await client.GetAsync($"?q={cityName}&appid={api_key}");
                    response.EnsureSuccessStatusCode();
                       var stringResult = await response.Content.ReadAsStringAsync();
                        var rawWeather = JsonConvert.DeserializeObject<OpenWeatherResponse>(stringResult);
                        temp = rawWeather.Main.Temp;

                    
                    
                }
                catch (HttpRequestException httpRequestException)
                {
                    _logger.LogError("Error in Getting temperature from Weather API", httpRequestException.Message);

                }
                return temp;
            }
        }
    }
}
