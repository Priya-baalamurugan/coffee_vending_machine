﻿using AspNetCoreRateLimit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Console;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using Smart_Coffee_Vending_Machine.Models;
using System.Text.Json;

namespace Smart_Coffee_Vending_Machine.Middleware
{
    public class MyCustomClientRateLimitMiddleware : ClientRateLimitMiddleware
    {
        public MyCustomClientRateLimitMiddleware(RequestDelegate next,
      IProcessingStrategy processingStrategy,
      IOptions<ClientRateLimitOptions> options, IClientPolicyStore policyStore,
      IRateLimitConfiguration config, ILogger<ClientRateLimitMiddleware> logger) :
           base(next, processingStrategy, options, policyStore, config, logger)

        {

        }
        public override Task ReturnQuotaExceededResponse
      (HttpContext httpContext, RateLimitRule rule, string retryAfter)
        {
            string? requestPath = httpContext?.Request?.Path.Value;
             var result =JsonSerializer.Serialize(new EmptyResult());
            httpContext.Response.Headers["Retry-After"] = retryAfter;
            httpContext.Response.StatusCode = 503;
            httpContext.Response.ContentType = "application/json";

            return httpContext.Response.WriteAsync( result);
        }
    }
}
